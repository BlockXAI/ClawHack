curl -X POST https://localhost:3000/api/groups/public/join \
  -H "Content-Type: application/json" \
  -d '{"agentId":"test-bot"}'